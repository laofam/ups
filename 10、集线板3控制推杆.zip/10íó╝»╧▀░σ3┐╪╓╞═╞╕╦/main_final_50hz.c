/*
 * STC8G1K08A-36I-SOP8 PWM 测量与控制系统程序
 * 【v2.1 逻辑检测修复版（基于 v2.0 阈值开关版）】
 * v2.1 修复：
 *   ① Timer1 中断内补装 10ms 初值（Mode 1 非自动重装，否则首次 10ms 后每次
 *      需数满 65536≈32.768ms 才溢出，实际启动延时≈633ms 而非 200ms）；
 *   ② 读 Timer0 时基循环内联至 INT0/INT1 各自中断（独立局部变量），
 *      消除 INT0 抢占 INT1 时覆盖 Get_Timer0 静态局部的重入竞态；
 *
 * 功能说明：
 * 1. 上电后 200ms 内：P5.5 输出低电平，推杆两路全高电平，忽略所有输入
 * 2. 200ms 后正常工作：
 *    - 舵机通道（8脚 P3.3 输入 PWM → 3脚 P5.5 输出）：
 *        输入高电平脉宽 < 1700us → P5.5 输出低电平
 *        输入高电平脉宽 >= 1700us → P5.5 输出高电平
 *        （每个有效下降沿立即更新；无效脉宽保持原输出状态）
 *    - 推杆通道（7脚 P3.2 输入 PWM → P3.0/P3.1 输出）：与旧版完全相同，未改动
 * 3. 旧版的 50Hz PWM 生成（Timer1 翻转）与 40us/脉冲 限速逻辑已删除
 * 4. 已严格遵守 Keil C51 规则：所有局部变量只能在函数最开头定义
 */

#include "STC8H.H"
#include <intrins.h>

// ==================== 类型定义 ====================
typedef unsigned char u8;
typedef unsigned int u16;

// ==================== 系统配置 ====================
#define SYS_CLOCK 24000000UL
#define T0_CLOCK (SYS_CLOCK / 12)

// ==================== 有效范围定义 ====================
#define INVALID_MIN 500
#define INVALID_MAX 2500
#define TIMEOUT_US 2500

// ==================== 舵机阈值定义 ====================
#define SERVO_THRESHOLD_US 1700    // 输入脉宽阈值：<1700us 输出低，>=1700us 输出高

// ==================== 启动延时参数 ====================
#define STARTUP_TICKS 20           // 20 × 10ms = 200ms
#define TICK_10MS_COUNTS 20000     // 10ms 对应计数值 @ 2MHz (Timer1, 12T 模式)

// ==================== 引脚定义 ====================
sbit SERVO_IN = P3^3;
sbit ROD_IN   = P3^2;
sbit ROD_OUT1 = P3^0;
sbit ROD_OUT2 = P3^1;
sbit SERVO_OUT = P5^5;

// ==================== 全局变量 ====================
volatile u16 g_t0_rising_servo = 0;
volatile u16 g_t0_rising_rod = 0;

volatile bit g_waiting_falling_servo = 0;
volatile bit g_waiting_falling_rod = 0;

volatile bit g_servo_valid = 0;
volatile bit g_rod_valid = 0;

volatile u16 g_servo_input_us = 1500;
volatile u16 g_rod_input_us = 1500;

// 开机 200ms 延时
volatile bit g_in_startup = 1;
volatile u8  g_delay_counter = 0;

// 注：读 Timer0 的双读校验循环已分别内联到 INT0/INT1 中断内（各自独立局部变量）。
// 原因：Keil C51 的函数局部变量为静态覆盖分配，若共用一个读取函数，
// INT0（高优先级）抢占 INT1（低优先级）时会覆盖其静态局部，产生竞态。

// ==================== 函数声明 ====================
void System_Init(void);
void GPIO_Init(void);
void Timer0_Measure_Init(void);
void Timer1_Startup_Tick_Init(void);
void Interrupt_Init(void);
void Process_Servo_Input(u16 us_value);
void Process_Rod_Input(u16 us_value);
void Update_Rod_Output(void);

// ==================== 主函数 ====================
void main(void)
{
    System_Init();
   
    ROD_OUT1 = 1;
    ROD_OUT2 = 1;
    SERVO_OUT = 0;                 // 启动期间 P5.5 固定输出低电平
   
    EA = 1;
   
    while(1) _nop_();
}

// ==================== 系统初始化 ====================
void System_Init(void)
{
    WDT_CONTR = 0x00;
    GPIO_Init();
    Timer0_Measure_Init();
    Timer1_Startup_Tick_Init();
    Interrupt_Init();
}

// ==================== GPIO 初始化 ====================
void GPIO_Init(void)
{
    P0M0 = 0x00; P0M1 = 0x00;
    P1M0 = 0x00; P1M1 = 0x00;
    P2M0 = 0x00; P2M1 = 0x00;
   
    P3M0 = 0x03;
    P3M1 = 0x0C;
    P3 |= 0x03;
   
    P5M0 |= 0x20;
    P5M1 &= ~0x20;
   
    SERVO_OUT = 0;
}

// ==================== Timer0 初始化 ====================
void Timer0_Measure_Init(void)
{
    AUXR &= ~0x80;
    TMOD &= 0xF0;
    TMOD |= 0x01;
    TH0 = 0x00;
    TL0 = 0x00;
    TR0 = 1;
}

// ==================== Timer1 初始化（仅作 200ms 启动延时的 10ms 节拍）====================
void Timer1_Startup_Tick_Init(void)
{
    TMOD &= 0x0F;
    TMOD |= 0x10;
   
    TH1 = (65536 - TICK_10MS_COUNTS) >> 8;    // 10ms 定时 @ 2MHz (12T 模式)
    TL1 = (65536 - TICK_10MS_COUNTS) & 0xFF;
   
    TR1 = 1;
}

// ==================== 中断初始化 ====================
void Interrupt_Init(void)
{
    TCON &= ~0x05;
    IE = 0x8D;
    IP = 0x09;
}

// ==================== INT0 中断（推杆输入，高优先级）====================
void External_Int0_ISR(void) interrupt 0
{
    u16 t0_value, pulse_width;
    u8 rth, rtl;                 // 独立局部变量，不与 INT1 共享
    IE0 = 0;
    do
    {
        rth = TH0;
        rtl = TL0;
    } while (TH0 != rth);
    t0_value = ((u16)rth << 8) | rtl;
    
    if (ROD_IN == 1)
    {
        g_t0_rising_rod = t0_value;
        g_waiting_falling_rod = 1;
    }
    else
    {
        if (g_waiting_falling_rod)
        {
            u16 rising = g_t0_rising_rod;
            pulse_width = (t0_value >= rising) ?
                          (t0_value - rising) >> 1 :
                          ((65536 - rising) + t0_value) >> 1;
            if (pulse_width <= TIMEOUT_US)
                Process_Rod_Input(pulse_width);
        }
        g_waiting_falling_rod = 0;
    }
}

// ==================== INT1 中断（舵机输入）====================
void External_Int1_ISR(void) interrupt 2
{
    u16 t0_value, pulse_width;
    u8 rth, rtl;                 // 独立局部变量，不与 INT0 共享
    IE1 = 0;
    do
    {
        rth = TH0;
        rtl = TL0;
    } while (TH0 != rth);
    t0_value = ((u16)rth << 8) | rtl;
    
    if (SERVO_IN == 1)
    {
        g_t0_rising_servo = t0_value;
        g_waiting_falling_servo = 1;
    }
    else
    {
        if (g_waiting_falling_servo)
        {
            u16 rising = g_t0_rising_servo;
            pulse_width = (t0_value >= rising) ?
                          (t0_value - rising) >> 1 :
                          ((65536 - rising) + t0_value) >> 1;
            if (pulse_width <= TIMEOUT_US)
                Process_Servo_Input(pulse_width);
        }
        g_waiting_falling_servo = 0;
    }
}

// ==================== Timer1_ISR（200ms 启动延时计数）====================
void Timer1_ISR(void) interrupt 3
{
    // Mode 1 非自动重装，必须在中断内重装初值，否则节拍不均匀（首次10ms，后续32.768ms）
    TH1 = (65536 - TICK_10MS_COUNTS) >> 8;
    TL1 = (65536 - TICK_10MS_COUNTS) & 0xFF;
    if (g_in_startup)
    {
        g_delay_counter++;
        if (g_delay_counter >= STARTUP_TICKS)      // 20 × 10ms = 200ms
        {
            g_in_startup = 0;
            TR1 = 0;                               // 启动延时结束，停止 Timer1
        }
    }
}

// ==================== 处理函数（所有变量在开头定义）================
void Process_Servo_Input(u16 us_value)
{
    u16 clamped;                 // 必须在函数最开头定义
    
    if (g_in_startup) return;
    
    clamped = (us_value < INVALID_MIN || us_value > INVALID_MAX) ? 0 :
              (us_value >= 500 && us_value < 1000) ? 1000 :
              (us_value > 2000 && us_value <= 2500) ? 2000 : us_value;
    
    if (clamped == 0) { g_servo_valid = 0; return; }   // 无效脉宽：保持原输出状态
    
    g_servo_valid = 1;
    g_servo_input_us = clamped;
    
    // 阈值开关输出：<1700us 输出低电平，>=1700us 输出高电平
    SERVO_OUT = (clamped >= SERVO_THRESHOLD_US) ? 1 : 0;
}

void Process_Rod_Input(u16 us_value)
{
    u16 clamped;                 // 必须在函数最开头定义
    
    if (g_in_startup) return;
    
    clamped = (us_value < INVALID_MIN || us_value > INVALID_MAX) ? 0 :
              (us_value >= 500 && us_value < 1000) ? 1000 :
              (us_value > 2000 && us_value <= 2500) ? 2000 : us_value;
    
    if (clamped == 0) { g_rod_valid = 0; return; }
    
    g_rod_valid = 1;
    g_rod_input_us = clamped;
    Update_Rod_Output();
}

void Update_Rod_Output(void)
{
    // 无局部变量
    if (g_rod_input_us >= 1000 && g_rod_input_us < 1500)
    {
        ROD_OUT1 = 1; ROD_OUT2 = 0;
    }
    else if (g_rod_input_us >= 1500 && g_rod_input_us <= 2000)
    {
        ROD_OUT1 = 0; ROD_OUT2 = 1;
    }
}
